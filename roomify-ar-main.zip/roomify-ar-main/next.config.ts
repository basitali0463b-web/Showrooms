import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  /* You can add other config options here later */
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: 'images.unsplash.com',
        port: '',
        pathname: '/**',
      },
    ],
  },
};

export default nextConfig;