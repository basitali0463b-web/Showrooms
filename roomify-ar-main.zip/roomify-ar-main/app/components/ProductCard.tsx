"use client";
import React from 'react';
import Image from "next/image";

// FIX: Added 'description' to the interface to match your data.ts
interface Product {
    id: number;
    name: string;
    price: string;
    sellerId: string;
    image: string;
    description: string; 
}

interface ProductCardProps {
    product: Product;
    role: 'user' | 'seller';
    onViewDetails: (product: Product) => void;
    onCreate3D: () => void;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, role, onViewDetails, onCreate3D }) => {
    return (
        <div className="group relative bg-slate-900/50 border border-white/5 rounded-3xl overflow-hidden hover:border-blue-500/50 hover:bg-slate-900 transition-all duration-500 shadow-2xl">
            
            {/* Image Section with Gradient Overlay */}
            <div className="relative h-56 w-full overflow-hidden">
                <div className="absolute inset-0 bg-linear-to-t from-slate-950/80 to-transparent z-10 opacity-60 group-hover:opacity-40 transition-opacity" />
                <Image 
                    src={product.image} 
                    alt={product.name}
                    fill 
                    className="object-cover group-hover:scale-110 transition-transform duration-700 ease-out"
                    sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                    priority={product.id < 104} 
                />
            </div>
            
            {/* Content Section */}
            <div className="p-6 relative">
                <div className="mb-4">
                    <h3 className="font-black text-xl text-white tracking-tight group-hover:text-blue-400 transition-colors">
                        {product.name}
                    </h3>
                    <div className="flex items-center gap-2 mt-1">
                        <span className="w-2 h-2 rounded-full bg-blue-500 animate-pulse" />
                        <span className="text-slate-500 text-[10px] font-bold uppercase tracking-tighter"> In progress</span>
                    </div>
                </div>
                
                <div className="flex justify-between items-center gap-4">
                    <div className="flex flex-col">
                        <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">Price</span>
                        <span className="text-white font-black text-xl tracking-tighter">{product.price}</span>
                    </div>
                    
                    {role === 'user' ? (
                        <button 
                            onClick={() => onViewDetails(product)}
                            className="flex-1 bg-white/5 hover:bg-blue-600 text-white text-xs font-bold px-4 py-3 rounded-2xl border border-white/10 hover:border-transparent transition-all duration-300 backdrop-blur-sm"
                        >
                            View Details
                        </button>
                    ) : (
                        <button 
                            onClick={onCreate3D}
                            className="flex-1 bg-blue-600 text-white text-xs font-bold px-4 py-3 rounded-2xl hover:bg-blue-500 transition-all duration-300 shadow-lg shadow-blue-600/20 active:scale-95"
                        >
                            Create 3D
                        </button>
                    )}
                </div>
            </div>

            {/* Bottom Accent Line */}
            <div className="absolute bottom-0 left-0 w-full h-0.5 bg-linear-to-r from-transparent via-blue-500/50 to-transparent scale-x-0 group-hover:x-100 transition-transform duration-700" />
        </div>
    );
};

export default ProductCard;