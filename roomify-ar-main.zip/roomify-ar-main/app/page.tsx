'use client'

import React, { useState, useEffect, Suspense, useRef } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import Navbar from './components/Navbar';
import ProductCard from './components/ProductCard';
import Image from "next/image";
import { ALL_PRODUCTS, SELLERS, Product, Seller } from './data';

// --- SUB-COMPONENT: SELLER ROW ---
// --- SUB-COMPONENT: PREMIUM SELLER ROW ---
const SellerRow = ({ seller, onClick }: { seller: Seller, onClick: () => void }) => {
  // Hardcoded rating for now, can be dynamic from data.ts

  return (
    <div
      onClick={onClick}
      className="group relative flex flex-col lg:flex-row items-center gap-8 p-6 bg-slate-800/30 border border-white/5 rounded-[3rem] hover:bg-slate-800/60 transition-all duration-500 cursor-pointer hover:border-blue-500/40 mb-8 overflow-hidden shadow-2xl"
    >
      {/* Decorative Gradient Background on Hover */}
      <div className="absolute top-0 right-0 -mr-20 -mt-20 w-64 h-64 bg-blue-600/5 blur-[100px] group-hover:bg-blue-600/10 transition-all duration-700" />

      {/* --- LOGO SECTION --- */}
      <div className="relative w-32 h-32 md:w-40 md:h-40 rounded-[2.5rem] overflow-hidden bg-slate-900 border border-white/10 shrink-0 shadow-2xl transition-transform duration-500 group-hover:scale-105">

        <div className="absolute inset-0 flex items-center justify-center text-5xl font-black text-blue-500 bg-blue-500/5 group-hover:bg-blue-500 group-hover:text-white transition-all duration-500 italic">
          {seller.name.charAt(0)}
        </div>
      </div>

      {/* --- INFO SECTION --- */}
      <div className="flex-1 text-center lg:text-left z-10">
        <div className="flex flex-col lg:flex-row lg:items-center gap-4 mb-4">
          <h3 className="text-4xl font-black text-white uppercase tracking-tighter italic leading-none">
            {seller.name}
          </h3>

          {/* Star Rating System */}
          <div className="flex items-center justify-center lg:justify-start gap-1">
            {[...Array(5)].map((_, i) => (
              <span key={i} className="text-yellow-400 text-lg">★</span>
            ))}
            <span className="ml-2 text-slate-500 text-[10px] font-black uppercase tracking-widest bg-white/5 px-2 py-1 rounded">
              Verified 5.0
            </span>
          </div>
        </div>

        {/* Company Professional Description */}
        <p className="text-slate-400 text-sm md:text-base leading-relaxed max-w-2xl mb-6 font-medium">
          {"Authorized distribution partner specializing in high-fidelity 3D assets and immersive spatial computing experiences. Delivering industry-standard quality for modern AR workflows."}
        </p>

        {/* Badges/Tags */}
        <div className="flex flex-wrap justify-center lg:justify-start gap-3">
          <span className="px-3 py-1 bg-blue-500/10 text-blue-400 text-[10px] font-black rounded-md uppercase tracking-[0.2em] border border-blue-500/20">
            Official Partner
          </span>
          <span className="px-3 py-1 bg-emerald-500/10 text-emerald-400 text-[10px] font-black rounded-md uppercase tracking-[0.2em] border border-emerald-500/20">
            AR Ready
          </span>
          <span className="px-3 py-1 bg-white/5 text-slate-400 text-[10px] font-medium rounded-md italic border border-white/10">
            {seller.email}
          </span>
        </div>
      </div>

      {/* --- ACTION SECTION --- */}
      <div className="px-10 py-5 bg-white text-black group-hover:bg-blue-600 group-hover:text-white rounded-4xl text-xs font-black uppercase tracking-[0.2em] transition-all duration-300 shadow-xl group-hover:shadow-blue-600/30 transform group-hover:-translate-x-2">
        Enter Showroom
      </div>
    </div>
  );
};

// --- SUB-COMPONENT: LOADING 3D (Wohi purani loading) ---
const Loading3D = ({ onClose, title }: { onClose: () => void; title: string }) => {
  const [status, setStatus] = useState<'loading' | 'soon'>('loading');

  useEffect(() => {
    const timer = setTimeout(() => setStatus('soon'), 2500);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="fixed inset-0 z-200 bg-slate-900/95 backdrop-blur-md flex items-center justify-center p-6">
      <div className="text-center space-y-6">
        {status === 'loading' ? (
          <div className="space-y-4">
            <div className="animate-spin w-16 h-16 border-4 border-t-blue-500 border-blue-500/10 rounded-full mx-auto" />
            <p className="text-slate-500 text-[10px] uppercase tracking-[0.3em] font-black animate-pulse">Initializing 3D Space</p>
          </div>
        ) : (
          <div className="space-y-6 animate-in zoom-in duration-500 text-white">
            <h2 className="text-5xl font-black uppercase italic tracking-tighter leading-none">
              Coming <span className="text-blue-500">Soon</span>
            </h2>
            <p className="text-slate-400 max-w-sm mx-auto font-medium">The 3D asset for <span className="text-white">{title}</span> is being processed for AR rendering.</p>
            <button onClick={onClose} className="px-12 py-4 bg-white text-black rounded-2xl font-black uppercase tracking-widest text-xs hover:bg-blue-600 hover:text-white transition-all">Close</button>
          </div>
        )}
      </div>
    </div>
  );
};

function DashboardContent() {
  const router = useRouter();
  const searchParams = useSearchParams();

  // Lazy Initialization for Auth
  const [role] = useState<'user' | 'seller'>(() => {
    if (typeof window !== 'undefined') return (localStorage.getItem('userRole') as 'user' | 'seller') || 'user';
    return 'user';
  });
  const [activeSellerId] = useState(() => (typeof window !== 'undefined' ? localStorage.getItem('activeSellerId') : null));
  const [userName] = useState(() => (typeof window !== 'undefined' ? localStorage.getItem('userName') || 'Guest' : 'Guest'));

  // Logic States
  const [products, setProducts] = useState<Product[]>(ALL_PRODUCTS);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isLaunching, setIsLaunching] = useState(false);
  const [newProduct, setNewProduct] = useState({ name: '', price: '', description: '', image: '' });
  const fileInputRef = useRef<HTMLInputElement>(null);

  const viewingSellerId = (role === 'seller') ? activeSellerId : searchParams.get('seller');
  const filteredProducts = viewingSellerId ? products.filter(p => p.sellerId === viewingSellerId) : [];
  const currentSeller = SELLERS.find(s => s.id === viewingSellerId);

  const handleAddProduct = (e: React.FormEvent) => {
    e.preventDefault();
    const p: Product = {
      id: Date.now(),
      name: newProduct.name,
      price: newProduct.price.startsWith('$') ? newProduct.price : `$${newProduct.price}`,
      sellerId: activeSellerId || 'unknown',
      image: newProduct.image || "https://images.unsplash.com/photo-1555041469-a586c61ea9bc?w=500",
      description: newProduct.description
    };

    // Pehly loading dikhao, phir product add karo
    setIsLaunching(true);
    setIsAddModalOpen(false);

    // Simulate processing
    setTimeout(() => {
      setProducts([p, ...products]);
      setNewProduct({ name: '', price: '', description: '', image: '' });
    }, 500);
  };

  return (
    <div className="min-h-screen bg-slate-700 text-slate-100 selection:bg-blue-500/30">
      <Navbar role={role} userName={userName} onLogout={() => { localStorage.clear(); window.location.href = '/'; }} />

      <main className="max-w-7xl mx-auto p-8">
        <header className="mb-12 flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div>
            {role === 'user' && viewingSellerId && (
              <button onClick={() => router.push('/dashboard')} className="mb-4 text-blue-400 font-black text-xs uppercase tracking-[0.2em] flex items-center gap-2 hover:text-white transition-colors group">
                <span className="group-hover:-translate-x-1 transition-transform">←</span> Back to Showrooms
              </button>
            )}
            <h1 className="text-6xl font-black uppercase tracking-tighter text-white leading-none">
              {viewingSellerId ? (role === 'seller' ? 'My Storefront' : currentSeller?.name) : 'Explore '}
              <span className="text-transparent bg-clip-text bg-linear-to-r from-blue-400 to-indigo-600 block md:inline">
                {viewingSellerId ? ' Collection' : 'Partner Showrooms'}
              </span>
            </h1>
          </div>

          {role === 'seller' && (
            <button
              onClick={() => setIsAddModalOpen(true)}
              className="bg-blue-600 hover:bg-blue-500 text-white px-10 py-5 rounded-3xl font-black uppercase text-xs tracking-widest transition-all shadow-xl shadow-blue-600/20 active:scale-95"
            >
              + Add New Listing
            </button>
          )}
        </header>

        {!viewingSellerId ? (
          <div className="space-y-4">
            {SELLERS.map((s) => (
              <SellerRow key={s.id} seller={s} onClick={() => router.push(`?seller=${s.id}`)} />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10 animate-in fade-in slide-in-from-bottom-8 duration-700">
            {filteredProducts.map((p) => (
              <ProductCard
                key={p.id}
                product={p}
                role={role}
                onViewDetails={setSelectedProduct}
                onCreate3D={() => { setIsLaunching(true); setSelectedProduct(null); }}
              />
            ))}
          </div>
        )}
      </main>

      {/* --- ADD PRODUCT MODAL --- */}
      {isAddModalOpen && (
        <div className="fixed inset-0 bg-slate-900/95 backdrop-blur-2xl flex items-center justify-center z-150 p-6">
          <div className="bg-slate-900 border border-white/10 rounded-[3rem] max-w-lg w-full p-10 shadow-2xl animate-in zoom-in duration-300">
            <h2 className="text-3xl font-black text-white mb-8 uppercase italic tracking-tighter">Publish New Asset</h2>
            <form onSubmit={handleAddProduct} className="space-y-4">
              <div
                onClick={() => fileInputRef.current?.click()}
                className="h-48 border-2 border-dashed border-white/10 rounded-3xl flex items-center justify-center cursor-pointer hover:border-blue-500/50 bg-slate-800/30 relative overflow-hidden"
              >
                {newProduct.image ? <Image src={newProduct.image} alt="preview" fill className="object-cover" /> : <p className="text-slate-500 text-[10px] font-black uppercase tracking-widest">Select Image</p>}
              </div>
              <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={(e) => {
                const file = e.target.files?.[0];
                if (file) setNewProduct({ ...newProduct, image: URL.createObjectURL(file) });
              }} />
              <input required className="w-full bg-slate-800/50 border border-white/5 p-5 rounded-2xl outline-none focus:border-blue-500/50 text-white" placeholder="Product Name" value={newProduct.name} onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })} />
              <input required className="w-full bg-slate-800/50 border border-white/5 p-5 rounded-2xl outline-none focus:border-blue-500/50 text-white" placeholder="Price (e.g. 150)" value={newProduct.price} onChange={(e) => setNewProduct({ ...newProduct, price: e.target.value })} />
              <textarea required rows={3} className="w-full bg-slate-800/50 border border-white/5 p-5 rounded-2xl outline-none focus:border-blue-500/50 resize-none text-white" placeholder="Asset description..." value={newProduct.description} onChange={(e) => setNewProduct({ ...newProduct, description: e.target.value })} />
              <div className="flex gap-4 pt-4">
                <button type="button" onClick={() => setIsAddModalOpen(false)} className="flex-1 text-slate-500 font-bold uppercase text-xs tracking-widest">Cancel</button>
                <button type="submit" className="flex-1 bg-blue-600 text-white py-5 rounded-2xl font-black uppercase text-xs tracking-widest">Publish</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* --- PREVIEW MODAL --- */}
      {selectedProduct && (
        <div className="fixed inset-0 bg-slate-900/95 backdrop-blur-2xl flex items-center justify-center z-100 p-6 animate-in fade-in duration-300">
          <div className="bg-slate-900 border border-white/10 rounded-[3rem] max-w-2xl w-full p-2 relative shadow-2xl overflow-hidden group">
            <button onClick={() => setSelectedProduct(null)} className="absolute top-6 right-6 z-50 h-10 w-10 flex items-center justify-center rounded-full bg-slate-800 text-white hover:bg-white hover:text-black transition-all">✕</button>
            <div className="flex flex-col md:flex-row gap-8 p-8">
              <div className="w-full md:w-1/2 relative h-80 rounded-4xl overflow-hidden border border-white/5">
                <Image src={selectedProduct.image} alt={selectedProduct.name} fill className="object-cover transition-transform duration-700 group-hover:scale-110" />
              </div>
              <div className="w-full md:w-1/2 flex flex-col justify-between py-2 text-white">
                <div>
                  <h2 className="text-4xl font-black tracking-tighter mb-4 uppercase italic">{selectedProduct.name}</h2>
                  <p className="text-slate-400 text-sm leading-relaxed mb-6 font-medium">{selectedProduct.description}</p>
                  <span className="text-3xl font-black text-blue-400 tracking-tighter">{selectedProduct.price}</span>
                </div>
                <button onClick={() => { setIsLaunching(true); setSelectedProduct(null); }} className="w-full bg-white text-black py-4 rounded-2xl font-black uppercase text-xs tracking-widest mt-6 hover:bg-blue-600 hover:text-white transition-all shadow-xl active:scale-95">Launch AR Placement</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Loading Screen Overlay */}
      {isLaunching && (
        <Loading3D
          title={selectedProduct?.name || newProduct.name || "Premium Asset"}
          onClose={() => setIsLaunching(false)}
        />
      )}
    </div>
  );
}

export default function VirtualPlacementApp() {
  return (
    <Suspense fallback={<div className="min-h-screen bg-slate-700 flex items-center justify-center text-white">Loading...</div>}>
      <DashboardContent />
    </Suspense>
  );
}